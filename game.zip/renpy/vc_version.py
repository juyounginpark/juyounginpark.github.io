branch = 'master'
nightly = False
official = True
version = '8.4.0.25071206'
version_name = 'Tomorrowland'
